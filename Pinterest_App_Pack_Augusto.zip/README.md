# Pinterest

Base para la aplicación personal **Augusto Pinterest Idea Library**.

## Objetivo
Consultar y organizar tableros y pines propios de Pinterest para convertirlos en una biblioteca de referencias de diseño y desarrollo de productos.

## Publicar con GitHub Pages
1. Subí estos archivos a la raíz del repositorio `Pinterest`.
2. En GitHub: Settings → Pages.
3. En "Build and deployment", elegí "Deploy from a branch".
4. Branch: `main` y carpeta `/ (root)`.
5. Guardá.
6. GitHub mostrará la URL pública del sitio.

Usá:
- URL principal del sitio como "Website".
- `.../privacy.html` como "Privacy Policy URL".
- `.../terms.html` como "Terms URL", si Pinterest lo solicita.

## Seguridad
No subas a GitHub:
- App Secret
- Access Tokens
- Refresh Tokens
- contraseñas o claves privadas

Esos valores deben guardarse en secretos o variables de entorno.
